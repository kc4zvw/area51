//

#include<iostream>

using namespace std;

struct temp
{
	float f;
	int i;
};

int main()
{
	temp *ptr;
	return 0;
}

