//

#include <iostream>
#include <cstring>

using namespace std;

void printBook(struct Books *book);

struct Books
{
	char title[50];
	char author[50];
	char subject[100];
	int book_id;
};

int main()
{
	struct Books Book1;
	struct Books Book2;

	strcpy(Book1.title, "Mathematics for IITJEE");
	strcpy(Book1.author, "RD Sharma");
	strcpy(Book1.subject, "JEE Mathematics");
	Book1.book_id = 6495407;

	strcpy(Book2.title, "Physics");
	strcpy(Book2.author, "IE Irodov");
	strcpy(Book2.subject, "JEE Mechanical Physics");
	Book2.book_id = 6495700;

	printBook( &Book1 );
	printBook( &Book2 );

	return 0;
}

void printBook(struct Books *book)
{
	cout << endl;
	cout << "  Book title: " << book->title << endl;
	cout << " Book author: " << book->author << endl;
	cout << "Book subject: " << book->subject << endl;
	cout << "     Book id: " << book->book_id << endl;
}

/* end */
