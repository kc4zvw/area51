
// C++ program for implementation of Heap Sort
#include <iostream>

using namespace std;

// To heapify a subtree rooted with node i which is
// an index in arr[]. n is size of heap
void heapify(int arr[], int n, int i)
{
	int largest = i; // Initialize largest as root
	int l = 2 * i + 1; // left = 2*i + 1
	int r = 2 * i + 2; // right = 2*i + 2

	// If left child is larger than root
	if (l < n && arr[l] > arr[largest])
		largest = l;

	// If right child is larger than largest so far
	if (r < n && arr[r] > arr[largest])
		largest = r;

	// If largest is not root
	if (largest != i) {
		swap(arr[i], arr[largest]);

		// Recursively heapify the affected sub-tree
		heapify(arr, n, largest);
	}
}

// main function to do heap sort
void heapSort(int arr[], int n)
{
	// Build heap (rearrange array)
	for (int i = n / 2 - 1; i >= 0; i--)
		heapify(arr, n, i);

	// One by one extract an element from heap
	for (int i = n - 1; i > 0; i--) {
		// Move current root to end
		swap(arr[0], arr[i]);

		// call max heapify on the reduced heap
		heapify(arr, i, 0);
	}
}

/* A utility function to print array of size n */
void printArray(int arr[], int n)
{
	for (int i = 0; i < n; ++i)
		cout << arr[i] << " ";
	cout << "\n";
}

// Driver code
int main()
{
	// int arr[] = { 12, 11, 13, 5, 6, 7 };
	int arr[] = {	100, 30, 165, 121, 122, 198, 35, 118, 69, 110, 
					2, 36, 3, 197, 158, 75, 28, 183, 107, 163, 
					85, 43, 52, 98, 64, 1, 84, 68, 113, 174, 
					14, 185, 45, 97, 139, 194, 87, 18, 186, 51, 
					10, 179, 138, 133, 132, 126, 94, 169, 79, 160, 
					93, 112, 33, 15, 182, 8, 191, 176, 145, 32, 
					143, 38, 150, 44, 73, 108, 123, 181, 61, 178, 
					80, 53, 5, 115, 23, 135, 154, 37, 70, 136, 
					95, 144, 92, 184, 102, 147, 167, 17, 192, 149, 
					83, 134, 13, 42, 65, 111, 47, 59, 22, 114, 
					76, 46, 31, 193, 21, 152, 141, 172, 39, 170, 
					117, 200, 72, 130, 71, 124, 49, 109, 81, 54, 
					34, 127, 199, 166, 88, 29, 77, 78, 86, 125, 
					4, 151, 105, 168, 142, 180, 189, 11, 140, 40, 
					196, 19, 99, 106, 89, 190, 120, 25, 20, 159, 
					175, 57, 195, 119, 60, 62, 58, 137, 82, 41, 
					177, 101, 187, 24, 146, 63, 164, 55, 173, 157, 
					12, 153, 148, 66, 162, 9, 26, 104, 96, 67, 
					48, 171, 128, 161, 188, 16, 74, 156, 27, 131, 
					129, 91, 56, 50, 6, 103, 155, 90, 7, 116 };

	int n = sizeof(arr) / sizeof(arr[0]);

	heapSort(arr, n);

	cout << "Sorted array is \n";
	printArray(arr, n);
}

/* End of file */
